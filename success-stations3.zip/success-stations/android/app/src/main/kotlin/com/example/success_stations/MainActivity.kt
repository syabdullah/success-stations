package com.successstations.success_stations

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
