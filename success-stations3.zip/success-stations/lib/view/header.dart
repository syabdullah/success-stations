/*
import 'package:flutter/material.dart';
import 'package:success_stations/styling/colors.dart';

Widget Header() {
  String title;

  Header(this.title);

  // const Header({Key? key}) : super(key: key);

  @override
  State<Header> createState() => _HeaderState();
}

class _HeaderState extends State<Header> {

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        color: AppColors.login_help
      ),
      child: Row(
        children: [
          Icon(Icons.arrow_back),
          Text(widget.title,style: TextStyle(color: Colors.white,fontSize: 15),),
        ],
      ),
    );
  }
}
*/
