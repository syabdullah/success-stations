class AppString {
  //company/Student signUp
  static String fullName = 'Full Name';
  static String email = 'E-mail';
  static String mobile = 'Mobile';
  static String country = 'Country';
  static String region = 'Region';
  static String city = 'City';
  static String university = 'University';
  static String college = 'College';
  static String termServices = 'I agree to the  ';



  //Stepper Screen

  static String istStep= "Annouce \n New";
  static String secStep= "Contact \n Information";
  static String thrStep= "Review and \n Publish";
  static String mobileNo = 'Mobile No.';
  static String telephoneNo = 'Telephone No.';
  static String type = 'TYPE';
  static String adnumber = 'AD NUMBER';
  static String citystep= "CITY";
  static String section = 'SECTION';
  static String details = 'DETAILS';
  static String saveAsDraft = 'SAVE AS DRAFT';
  static String publish = 'PUBLISH';
  static String status = 'STATUS';
  // static String details = 'DETAILS';

  static String signUp = 'SIGN UP';
  // static String termServices = 'I agree to the';
  // static String signUp = 'SIGN UP';
  static String idIqama = 'ID/ Iqama';
  static String response = 'Responsible';
  static String mobNum = 'Mobile Number';
  static String accType = 'Account Type :';
  static String dob = 'YYYY-MM-DD';
  static String accountType = 'Account Type:';
  static String companyName = 'Company Name';
  static String cr = 'CR';


  
  static String existAccount = 'Do you have and account?';
  static String termCondition = '  Terms and Conditions';

  // Sign In
  static String loginEmail = 'Phone Number,email or name';
  static String password = 'Password';
  static String google = 'Google';
  static String facebook = 'Facebook';
  static String signIn = 'SIGN IN';
  static String forgotPass = 'Forgot Password?';
  static String goForSignup = 'Don\'t have an account? ';

//AppDrawer

  static String profile = "PROFILE";
  static String menu = "MAIN MENU";
  static String overview = "OVERVIEW AND DEFINATIONS";

  //Add Posting Screen
  static String seeProfile = "See Profile";
  static String adpostedat = "Ad Posted at";
  static String addComment = "ADD COMMENT";
  static String contact = "CONTACT";
  static String fav =  "FAVOURITES";
  static String report  = "Report";
  static String namec = 'NAME';
  static String adress = 'ADRESS';
  static String mobilec = 'MOBILE';
   static String emailc = 'EMAIL';
   
  // friend list

  static String filter = 'Filter';
  static String filters = 'Filters';
  static String cancel = 'Cancel';
  static String addFriend = 'Add Friend';
  static String remove = 'Remove';
  static String name = 'Name';
  static String address = 'Address';
  static String smester = 'Semester';
  static String degree = 'Degree';

  // ads 
   static String cato = 'Advertising Categories';
   static String all = 'All';
   static String featured = 'Featured Ads';
   static String specialOffer = 'Special Offer';
   static String titleHere = 'Title Here';
   static String lastOffer = 'Last Offers';
   static String lastAds = 'Last Ads';
   static String lastLocations = 'Last Locations';
   
  static String login = 'LOGIN';
  //forgotPassword
  static String next = 'NEXT';
  static String recieveEmailID = 'Type your email-ID to recieve password by Email.';
  static String emailAddress = 'Email address';
  static String digitsCode = 'Enter the 4 digits code';
  static String codeMail = 'Enter the 4 digits code that you recieved in your email';
  //reset password 
 static String resetPassword = 'Reset Password';
 static String resetSetPass =  'Set the new password to login';
 static String resetButton = 'CANCEL';
 static String newPass = 'New Password';
 static String confirmPass = ' Confirm Password';
  static String changedPasww = 'Password Changed,';
 static String successResetPass=  'You can now login with your new password';
  static String forgotPassText= 'Forgot Password';
//contact
 static String send = 'SEND';
  static String phoneNumber = 'Phone Number';


}