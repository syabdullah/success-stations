import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:success_stations/styling/colors.dart';
import 'package:success_stations/styling/images.dart';
import 'package:success_stations/styling/text_style.dart';
import 'package:success_stations/view/about_us.dart';
import 'package:success_stations/view/add_posting_screen.dart';

class CustomBottomBar extends StatefulWidget {
  const CustomBottomBar({ Key? key }) : super(key: key);

  @override
  _CustomBottomBarState createState() => _CustomBottomBarState();
}

class _CustomBottomBarState extends State<CustomBottomBar> {
  int _currentIndex = 0;
  void onTabTapped(int index) {
    setState(() {
      _currentIndex = index;
    });
  }
  @override
  Widget build(BuildContext context) {
    return   BottomNavigationBar(


      currentIndex: _currentIndex,

        onTap: (value) {
        setState(() => _currentIndex = value);
          _currentIndex == 0 ? Get.off(AddPostingScreen())  : Get.off(AboutUs());
          
        },
        items: [
            BottomNavigationBarItem(

              // ignore: deprecated_member_use

              icon: ImageIcon(AssetImage(AppImages.offers,),),
            ),
            BottomNavigationBarItem(
              // ignore: deprecated_member_use

              icon:ImageIcon(AssetImage(AppImages.friends)),
            ),
            BottomNavigationBarItem(
              // ignore: deprecated_member_use

              icon: ImageIcon(AssetImage(AppImages.locations)),
            ),
            BottomNavigationBarItem(
              // ignore: deprecated_member_use

              icon:ImageIcon(AssetImage(AppImages.ads)),
            ),
        ],
      
    );
  }
}
