class Config{
 String baseUrl = "https://success-stations.com/beta/public/index.php/api/v1/";
}